#' Run adjustment method
#'
#' @param formula Formula interface for outcome model.
#' @param data Linked data set with variables for outcome and mismatch indicator models.
#' @param family Distribution of response variable
#' @param m.formula One-sided formula interface for the mismatch indicator model.
#' @param safematches Indicator variable for safe matches. (TRUE if safe match, FALSE otherwise)
#' @param assumed_mrate Assumed overall mismatch rate (proportion)
#' @returns A list of results from the function called.
#' \item{betahat}{Outcome model beta coefficient estimates}
#' \item{sigmahat}{Residual standard error}
#' \item{hshatndonly}{Average correct match rate among records that may be mismatched}
#' \item{conv}{Track of negative log Pseudo-Likelihood}
#' \item{family}{Assumed distribution of the response variable in outcome model}
#' \item{sd_sandwich}{Estimated standard errors}
#' \item{gammahat}{Mismatch indicator model gamma coefficient estimates}
#' @export
#'
#' @examples
#' fit_mixture(formula = surv_age ~ poly(uyob, 3, raw = TRUE), demodata,
#'             m.formula = ~ commf + comml,
#'             safematches = ifelse(demodata$hndlnk == "Hand-Linked At Some Level", TRUE, FALSE),
#'             assumed_mrate = 0.05)

fit_mixture <- function(formula, data, family = "Gaussian",
                        m.formula, safematches, assumed_mrate){
  # X: collection of covariate values
  # y: response values
  # logis_ps: covariates in logistic regression model for mismatch indicator
  X <- model.matrix(formula, data=data)
  y <- as.numeric(model.response(model.frame(formula, data = data)))

  n <- nrow(X) # number of observations (of covariates)
  p <- ncol(X) # number of covariates

  if(missing(m.formula)){
    logis_ps <- matrix(nrow = n, ncol = 1, data = 1)
  } else {
    logis_ps <- model.matrix(m.formula, data=data)
  }

  if(missing(safematches)){
    is_flagged <- rep(FALSE,n)
  } else {
    is_flagged <- safematches
  }

  if(!missing(assumed_mrate)){
    logitbound <- log(assumed_mrate)
  }

  # -------------------------------------------
  # some custom error messages regarding y, g, or init inputs
  if(length(y) != n)
    stop("Error: Length of 'y' must be equal to the number of rows of 'X' \n")
  # -------------------------------------------

  # pdf of normal distribution with mean = 0,
  # x = (y-mu)[sub], and sd = std
  fymu <- function(mu, sigma, sub) dnorm((y - mu)[sub], sd = sigma)

  # Gaussian model for y, x
  fymu_all_normal <- function(mu, std, sub){
    # pdf of normal distribution with mean = 0,
    # x = (y-mu)[sub], and sd = std
    fun <- dnorm((y - mu)[sub], sd = std)
    # derivative of fun with respect to beta
    d_fun_beta <- fun * (y - mu)[sub]/(std^2)
    # derivative of fun with respect to sigma
    d_fun_sigma <- fun*((y - mu)[sub]^2/std^3 - 1/std)
    # second derivative of fun with respect to beta
    d2_fun_beta <- d_fun_beta*(y - mu)[sub]/(std^2) - fun/(std^2)
    # second derivative of fun with respect to sigma
    d2_fun_sigma <- d_fun_sigma*((y - mu)[sub]^2/std^3 - 1/std) + fun*(1/std^2 - 3*(y - mu)[sub]^2/std^4)
    # derivative of fun with respect to beta and sigma
    d2_fun_beta_sigma <- d_fun_sigma*(y - mu)[sub]/(std^2) - 2*fun*(y - mu)[sub]/(std^3)
    # return output
    return(list(fun = fun, dfun_beta = d_fun_beta, dfun_sigma = d_fun_sigma, d2fun_beta = d2_fun_beta, d2fun_sigma = d2_fun_sigma, d2fun_beta_sigma = d2_fun_beta_sigma))
  }

  # density function of the marginal distribution of y
  g <- function(y){
    dnorm(y, mean = mean(y), sd = sd(y))
  } # Gaussian density

  fy <- g(y)

  # negative log likelihood of the mixture model
  # The EM algorithm decreases this function in every iteration
  nloglik <- function(mu, sigma, hs){
    sum(-log(hs[!is_flagged] * fymu(mu, sigma, !is_flagged) + (1 - hs[!is_flagged])* fy[!is_flagged])) - sum(log(fymu(mu, sigma, is_flagged)))
  }

  # starting values for beta and sigma in the EM
  # algorithm when init = LS
  betacur <- solve(crossprod(X), crossprod(X, y))
  stdcur <- sqrt(sum((y - X %*% betacur)^2)/(n-p))

  # hs - models the probabilities of a correct
  # match P(m = 0|delta_{i})
  hgamma_gamma <- function(gamma, subs){
    return(list(fun = rep(gamma, sum(subs)), dfun = rep(1, sum(subs)), d2fun = rep(0, sum(subs))))
  }

  hs <- hgamma_gamma(0.5, !is_flagged)$fun

  # models for the mismatch indicator
  # based on delta & m relationship
  # Logistic model for mismatches
  Delta <- logis_ps

  hgamma <- function(eta){
    pi <- plogis(eta)
    return(list(fun = pi, dfun = pi*(1-pi), d2fun = pi*(1-pi)*(1 - 2*pi)))
  }

  if(!missing(assumed_mrate)){
    gammacur <- c(min(logitbound, 0), rep(0, ncol(Delta)-1))
  } else {
    gammacur <- rep(0, ncol(Delta))
  }
  hs <- hgamma(Delta %*% gammacur)$fun

  # -------------------------------------------
  # EM Algorithm

  # starting iteration
  iter <- 1
  # the maximum iterations of the EM algorithm
  maxiter <- 1000
  # the tolerance for the EM algorithm
  # end the algorithm if the nloglik result does not change
  # by at least this value compared to the previous iteration
  tol <- 1E-4
  # function's objective values (expect it to decrease)
  objs <- numeric(maxiter)
  # conditional mean of y given x
  mucur = X%*%betacur
  # starting nloglik
  nloglik_cur <- nloglik(mucur, stdcur, hs)
  objs[iter] <- nloglik_cur
  # variable for E-step
  pcur = rep(0,n)

  ### iterations
  while(iter < maxiter){
    ## E-step
    # conditional probability of correct match
    # when not deterministic match
    num <-  hs[!is_flagged] * fymu(mucur, stdcur,!is_flagged)
    denom <- num + (1-hs[!is_flagged]) * fy[!is_flagged]
    pcur[!is_flagged] <- num/denom
    pcur[is_flagged] <- 1 # when deterministic match
    gammacur <- mean(pcur)

    ## M-step
    # constant mismatch probability if we do not
    # use degradation or logisRegMp
    # hs - match probabilities
    hs <- hgamma_gamma(mean(pcur), !is_flagged)$fun

    # gamma for the delta-m model
    # minimize function with respect to gamma
    # depends on what model we have for "h"
    if(!missing(assumed_mrate)){
      glm_h <- constrained_logistic_regression(Delta[!is_flagged,], 1-pcur[!is_flagged], logitbound)
      gammacur <- -glm_h$beta
    } else {
      glm_h <- glm(pcur[!is_flagged] ~ Delta[!is_flagged,] - 1, family = quasibinomial)
      gammacur <- coef(glm_h)
    }

    hs <- hgamma(Delta %*% gammacur)$fun

    # theta parameter is for the regression model
    # minimize function with respect to theta
    # fit a glm with weights - m_hat
    wglmfit <- glm(y ~ X - 1, family = gaussian, weights = pcur)
    betacur <- coef(wglmfit)
    mucur <- X %*% betacur

    stdcur <- sqrt(weighted.mean((y - mucur)^2, w = pcur))

    ## Evaluate the objective value
    iter <- iter + 1
    objs[iter] <- nloglik(mucur, stdcur, hs)
    # stop if the progress made since the last iteration
    # is too small
    if(objs[iter] + tol > objs[iter-1]){
      break
    }
  }
  # -------------------------------------------
  ### OBTAIN STANDARD ERRORS
  fymu_all_eval <- fymu_all_normal(mucur, stdcur, !is_flagged)
  hgamma_eval <- hgamma_gamma(mean(pcur), !is_flagged)

  hgamma_eval <- hgamma(Delta[!is_flagged,] %*% as.matrix(gammacur))

  # beta, score, numerator
  mixprob <- fy[!is_flagged] * (1 - hgamma_eval$fun) + hgamma_eval$fun * fymu_all_eval$fun

  w_beta_score_num <- (-1) * fymu_all_eval$dfun_beta*hgamma_eval$fun
  w_beta_score_denom <- mixprob
  w_beta_score <- w_beta_score_num/w_beta_score_denom

  w_sigma_score_num <- (-1) * fymu_all_eval$dfun_sigma*hgamma_eval$fun
  w_sigma_score_denom <- mixprob
  w_sigma_score <- w_sigma_score_num/w_sigma_score_denom

  w_gamma_score_num <- (-1) * (fymu_all_eval$fun - fy[!is_flagged])*hgamma_eval$dfun
  w_gamma_score_denom <- mixprob
  w_gamma_score <- w_gamma_score_num/w_gamma_score_denom

  w1 <- w_beta_score^2
  w2 <- w_sigma_score^2
  w3 <- w_gamma_score^2

  Xw1 <- sweep(X[!is_flagged,], MARGIN = 1, STATS = w_beta_score, FUN = "*")
  Xw2 <- sweep(matrix(nrow = sum(!is_flagged), ncol = 1, data = 1), MARGIN = 1, STATS = w_sigma_score, FUN = "*")
  Deltaw3 <- sweep(as.matrix(Delta[!is_flagged,]), MARGIN = 1, STATS = w_gamma_score, FUN = "*")

  meat <- crossprod(cbind(Xw1, Xw2, Deltaw3))

  w_beta2_hess <- (-(hgamma_eval$fun * fymu_all_eval$d2fun_beta)/mixprob) + (w_beta_score)^2
  w_sigma2_hess <- (-(hgamma_eval$fun * fymu_all_eval$d2fun_sigma)/mixprob) + (w_sigma_score)^2
  w_gamma2_hess <- ((-(fymu_all_eval$fun - fy[!is_flagged])*hgamma_eval$d2fun)/mixprob) + (w_gamma_score)^2
  w_beta_gamma_hess <- (-(fymu_all_eval$dfun_beta * hgamma_eval$dfun)/mixprob) + ((fymu_all_eval$fun - fy[!is_flagged])*(hgamma_eval$fun)*hgamma_eval$dfun*fymu_all_eval$dfun_beta)/(mixprob^2)
  w_sigma_gamma_hess <- (-(fymu_all_eval$dfun_sigma * hgamma_eval$dfun)/mixprob) + ((fymu_all_eval$fun - fy[!is_flagged])*(hgamma_eval$fun)*hgamma_eval$dfun*fymu_all_eval$dfun_sigma)/(mixprob^2)
  w_beta_sigma_hess <- (-(fymu_all_eval$d2fun_beta_sigma * hgamma_eval$dfun)/mixprob) + w_beta_score * w_sigma_score

  Xw4 <- sweep(X[!is_flagged,], MARGIN = 1, STATS = w_beta2_hess, FUN = "*")
  Deltaw6 <- sweep(as.matrix(Delta[!is_flagged,]), MARGIN = 1, STATS = w_gamma2_hess, FUN = "*")
  Xw5 <-  sweep(X[!is_flagged,], MARGIN = 1, STATS = w_beta_gamma_hess, FUN = "*")
  d <- ncol(X)
  Hess <- matrix(nrow = d + 1 + ncol(Delta), ncol =  d + 1 + ncol(Delta))
  one_vector <- matrix(nrow = sum(!is_flagged), ncol = 1, data = 1)
  Hess[1:d, 1:d] <- crossprod(X[!is_flagged,], Xw4)
  Hess[d+1, d+1] <- crossprod(one_vector, sweep(one_vector, MARGIN = 1, STATS = w_sigma2_hess, FUN = "*"))
  Hess[(d+2):(d+ncol(Delta)+1), (d+2):(d+ncol(Delta)+1)] <- crossprod(Delta[!is_flagged,], Deltaw6)
  Hess[1:(d+1), (d+2):(d+ncol(Delta)+1)] <- rbind(crossprod(Xw5, Delta[!is_flagged,]), crossprod(sweep(one_vector, MARGIN = 1, STATS = w_sigma_gamma_hess, FUN = "*"), Delta[!is_flagged,]))
  Hess[(d+2):(d+ncol(Delta)+1), 1:(d+1)] <- t(Hess[1:(d+1), (d+2):(d+ncol(Delta)+1)])
  Hess[1:d, d+1] <- crossprod(X[!is_flagged,], sweep(one_vector, MARGIN = 1, STATS = w_beta_sigma_hess, FUN = "*"))
  Hess[d+1, 1:d] <- t(Hess[1:d, d+1])

  cov_1_hat  <- solve(Hess, meat)
  covhat <- t(solve(Hess, t(cov_1_hat)))

  # sandwich estimator
  ses <- sqrt(diag(covhat))
  # label the estimated standard errors
  nam = NULL
  for (i in 1:(d+ncol(Delta)+1)){
    if(i <= d){nam[i] = paste0("beta", i-1)}
    if(i == d+1){nam[i] = paste0("sigma")}
    if(i>=d+2){nam[i] = paste0("gamma", i-(d+2))}
  }
  names(ses) <- nam

  # -------------------------------------------
  ### OUTPUTS

  return(list(betahat = betacur, sigmahat = stdcur,
              hshatndonly = hs[!is_flagged],
              conv = objs[1:(iter+1)], family = family,
              sd_sandwich = ses, gammahat = gammacur,
              call = match.call()))
}

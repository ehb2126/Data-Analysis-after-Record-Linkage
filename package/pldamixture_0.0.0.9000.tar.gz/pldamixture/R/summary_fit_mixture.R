#' Summarize `fit_mixture()` results
#'
#' @param output The result of a call to `fit_mixture()`
#' @returns A summary of the output.
#' \item{Family}{Assumed distribution of the response variable in outcome model}
#' \item{Beta}{Outcome model coefficients}
#' \item{Sigma}{Residual standard error}
#' \item{Gamma}{Mismatch indicator model coefficients}
#' @export
#'
#' @examples
#' fit <- fit_mixture(formula = surv_age ~ poly(uyob, 3, raw = TRUE), demodata,
#'             m.formula = ~ commf + comml,
#'             safematches = ifelse(demodata$hndlnk == "Hand-Linked At Some Level", TRUE, FALSE),
#'             assumed_mrate = 0.05)
#'
#' summary.fit_mixture(fit)

summary_fit_mixture <- function(output)
{
  l <- length(output$betahat)
  l2 <- length(output$betahat) + 2
  e <- length(output$sd_sandwich)
  TAB <- cbind(output$betahat, output$sd_sandwich[1:l])
  colnames(TAB) <- c("Estimate","StdErr")
  rownames(TAB) <- substring(rownames(TAB), first=2)
  TAB1 <- cbind(output$sigmahat, output$sd_sandwich[l+1])
  colnames(TAB1) <- c("Estimate","StdErr")
  rownames(TAB1) <- ""
  TAB2 <- cbind(output$gammahat, output$sd_sandwich[l2:e])
  colnames(TAB2) <- c("Estimate","StdErr")

  cat("Call:", sep="\n")
  print(output$call,quote=F)
  cat(" ", sep="\n")
  cat("Family:", output$family, "---", sep="\n")

  cat("Beta Coefficients:", sep="\n")
  print(TAB,quote=F)
  cat(" ", sep="\n")
  cat("Sigma:", sep="\n")
  print(TAB1,quote=F)
  cat(" ", sep="\n")
  cat("Gamma Coefficients:", sep="\n")
  print(TAB2,quote=F)
  cat("---", sep="\n")
  cat("Average Correct Match Rate Among Not Safe Matches:", mean(output$hshatndonly))

}

#' Constrained logistic regression function used in `fit_mixture()` when an overall mismatch rate is provided.
#' 
#' @param X Covariates in the outcome model.
#' @param y Response variable in the outcome model.
#' @param bound Logit of assumed overall mismatch rate
#' @returns A list of results.
#' \item{betacur}{Outcome model \beta coefficient estimates}
#' \item{objs}{Track of negative log Pseudo-Likelihood}
#' @export

constrained_logistic_regression <- function(X, y, bound){
  
  #browser()
  d <- ncol(X)
  #log(mean(mu)/(1-mean(mu)))
  #mean(X %*% beta)
  barx <- colMeans(X)
  
  
  nloglik_logistic <- function(mu){
    
    #mu <- plogis(X %*% beta)
    sum(-(y * log(mu) + (1-y) * log(1 - mu)))
    
  }
  grad_Hess <- function(mu){
    
    grad <- -crossprod(X, y - mu)
    w <- sqrt(mu * (1-mu))
    Xw <- sweep(X, MARGIN = 1, STATS = w, FUN = "*")
    Hess <- crossprod(Xw)
    
    return(list(grad = grad, Hess = Hess))
  }
  
  #betaglm <- coef(glm(y ~ X - 1, family = binomial))
  #betaglm[1] <- betaglm[1] - .45
  betacur <- c(bound, rep(0, d-1))
  mu <- plogis(X %*% betacur)
  iter <- 1
  maxiter <- 1000
  mu <- plogis(X %*% betacur)
  tol <- 1E-8
  objs <- numeric(maxiter)
  objs[1] <- nloglik_logistic(mu)
  while(iter < maxiter){
    
    
    gH <- grad_Hess(mu)
    gr <- gH$grad
    H <- gH$Hess
    
    rhs <- -gr + (H %*% betacur)
    betanew <- solve(H, rhs)
    
    eta_tmp <- X%*% betanew
    
    if(mean(eta_tmp) > bound){
      #    betacur <- betanew
      #    mu <- plogis(X %*% betacur)
      #    iter <- iter+1
      #    objs[iter] <- nloglik_logistic(mu)
      #}
      #else{
      
      betanew_theta <- solve(rbind(cbind(H,barx), c(barx,0)), c(rhs, bound))
      betanew <- betanew_theta[1:d]
      theta <- betanew_theta[d+1]
    }
    # linesearch
    foo <- function(gamma){
      betagamma <- (1-gamma) * betacur + gamma * betanew
      mu <- plogis(X %*% betagamma)
      nloglik_logistic(mu)
    }
    gammastar <- optimize(foo, interval = c(0,1))$minimum
    betacur <- (1-gammastar) * betacur + gammastar * betanew
    mu <- plogis(X %*% betacur)
    iter <- iter+1
    objs[iter] <- nloglik_logistic(mu)
    
    if(iter >= 2){
      if(objs[iter-1] - objs[iter] < tol)
        break
    }
    
  }
  
  return(list(beta = betacur, objs = objs))
  
}